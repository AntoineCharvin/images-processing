close all
clear all
clc

A=imread('holes.jpg');
seuil=10;
B=A(:,:,1)<seuil;
imshow(B)