close all
clear all
clc

A=imread('bubbles.bmp');
taille_masque=40;
se=logical(ones(taille_masque,taille_masque));
B=imopen(A,se);
imshow(B)