close all
clear all
clc

A=imread('eight_salt_pepper.bmp');
ga=fspecial('gaussian',5,3);
B=imfilter(A,ga);
imshow(B)
C=medfilt2(A);
figure, imshow(C)
so=fspecial('sobel')
D=imfilter(A,so);
figure, imshow(D)

