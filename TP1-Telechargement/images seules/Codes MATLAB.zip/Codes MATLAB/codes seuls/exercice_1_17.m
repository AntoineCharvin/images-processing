close all
clear all
clc

A=imread('eight_salt_pepper.bmp');
imshow(A)
so=fspecial('sobel')

D1=conv2(A,so');
D2=conv2(A,-so');
figure,imshow(uint8(D1))
figure,imshow(uint8(D2))


