close all
clc

data=regionprops(F);
size(data)

aires=[data.Area];
hist(aires)