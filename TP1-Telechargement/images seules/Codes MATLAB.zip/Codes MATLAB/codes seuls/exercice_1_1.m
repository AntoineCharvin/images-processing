close all
clear all
clc

A=imread('andromeda.bmp');
for i=1:size(A,1)
  for j=1:size(A,2)
    B(i,j,1)=255;
    B(i,j,2)=255;
    B(i,j,3)=255;
   end
end

imshow(B)
imwrite(B,'andromeda\_blanche.bmp');
    