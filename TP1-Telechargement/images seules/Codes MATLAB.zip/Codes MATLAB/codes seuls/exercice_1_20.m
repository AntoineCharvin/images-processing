close all
clear all
clc

A=imread('circles.png');
A=A(:,:,1);
se=logical(ones(5,5));
B=imdilate(A,se);
imshow(B,[])
