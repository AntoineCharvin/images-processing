close all
clear all
clc

A=imread('andromeda.bmp');
imshow(A)
