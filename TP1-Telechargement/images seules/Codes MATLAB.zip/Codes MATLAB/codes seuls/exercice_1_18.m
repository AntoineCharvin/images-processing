close all
clear all
clc

A=zeros(600,600);
A(151:450,151:450)=255*ones(300,300);
imshow(uint8(A))
so=fspecial('sobel')
D1=abs(conv2(A,so));
D2=abs(conv2(A,so'));

figure,imshow(uint8(D1+D2))
