close all
clear all
clc

for i=1:100
    B(1,i)=8;
end