close all
clear all
clc

A=imread('andromeda.bmp');
A=double(A);





A=uint8(A);
imshow(A)
