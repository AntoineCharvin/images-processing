clear all
close all
clc

A=imread('andromeda.bmp');
imshow(A)
