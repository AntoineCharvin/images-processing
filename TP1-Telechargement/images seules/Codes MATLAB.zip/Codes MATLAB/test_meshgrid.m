clear all
close all
clc

A1=imread('Signac_1.bmp');
A2=imread('Signac_2.bmp');

N_1=size(A1,1);
N_2=size(A1,2);

[X Y]=meshgrid(1:N_2,1:N_1);

Masque_A(:,:,1)=(X>Y*N_2/N_1);
Masque_A(:,:,2)=(X>Y*N_2/N_1);
Masque_A(:,:,3)=(X>Y*N_2/N_1);

R=100;
Masque_B(:,:,1)=((X-N_2/2).^2+(Y-N_1/2).^2>R^2);
Masque_B(:,:,2)=((X-N_2/2).^2+(Y-N_1/2).^2>R^2);
Masque_B(:,:,3)=((X-N_2/2).^2+(Y-N_1/2).^2>R^2);

imshow(uint8(Masque_A).*A1+uint8(1-Masque_A).*A2)
figure, imshow(uint8(Masque_B).*A1+uint8(1-Masque_B).*A2)